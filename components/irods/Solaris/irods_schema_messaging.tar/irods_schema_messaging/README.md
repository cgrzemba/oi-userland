irods_schema_messaging
======================

iRODS schema for RPC (API) Messages
